# Breezy Blush — Flutter starter

This is a demo appointment-booking UI for Breezy Blush. It is not yet connected to a shared database, and bookings are stored only in app memory. Do not use it for real customer bookings until cloud storage, authentication, and booking-conflict checks are implemented.

## Build an Android test APK

This repository includes a GitHub Actions workflow. Open the **Actions** tab and select **Build Breezy Blush APK**, then choose **Run workflow** if it has not already started. When the run finishes, download the `breezy-blush-debug-apk` artifact, extract it, and install `app-debug.apk` on your Android phone. This is a test/debug build.

import 'package:flutter/material.dart';

void main() => runApp(const BreezyBlushApp());

const burgundy = Color(0xFF7D1733);
const blush = Color(0xFFF8E9ED);
const barbers = [
  'Shoib Akhtar',
  'Javed Habib',
  "Javed Habib's Brother",
  "Shoib Akhtar's Partner",
];
const services = {
  'Haircut': 30,
  'Beard trim': 20,
  'Haircut + beard': 45,
  'Hair wash + haircut': 45,
};

class BreezyBlushApp extends StatelessWidget {
  const BreezyBlushApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Breezy Blush',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: burgundy),
          scaffoldBackgroundColor: const Color(0xFFFFFBFC),
          useMaterial3: true,
          appBarTheme: const AppBarTheme(
            backgroundColor: burgundy,
            foregroundColor: Colors.white,
            centerTitle: false,
          ),
        ),
        home: const BookingHome(),
      );
}

class BookingHome extends StatefulWidget {
  const BookingHome({super.key});

  @override
  State<BookingHome> createState() => _BookingHomeState();
}

class _BookingHomeState extends State<BookingHome> {
  String? barber;
  String service = services.keys.first;
  DateTime date = DateTime.now().add(const Duration(days: 2));
  String? time;
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final bookings = <Map<String, String>>[];

  List<DateTime> get availableDates => List.generate(
      6, (i) => DateTime.now().add(Duration(days: i + 2)));

  @override
  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    super.dispose();
  }

  Future<void> chooseDate() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: date,
      firstDate: DateTime(now.year, now.month, now.day + 2),
      lastDate: DateTime(now.year, now.month, now.day + 7),
    );
    if (selected != null) setState(() { date = selected; time = null; });
  }

  void submit() {
    final name = nameController.text.trim();
    final phone = phoneController.text.trim();
    if (barber == null || time == null || name.isEmpty || phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Choose a barber, time, and enter your name and mobile number.'),
      ));
      return;
    }
    setState(() {
      bookings.add({
        'name': name,
        'phone': phone,
        'barber': barber!,
        'service': service,
        'date': '${date.day}/${date.month}/${date.year}',
        'time': time!,
      });
    });
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Demo booking added'),
        content: const Text(
          'This booking is stored only on this screen for demonstration. '
          'It is not sent to the shop and does not reserve a real time slot yet.',
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context),
          child: const Text('OK'))],
      ),
    );
    setState(() { time = null; });
  }

  @override
  Widget build(BuildContext context) {
    final dateLabel = '${date.day}/${date.month}/${date.year}';
    return Scaffold(
      appBar: AppBar(
        title: const Text('BREEZY BLUSH'),
        actions: [
          IconButton(
            tooltip: 'My demo bookings',
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => BookingList(bookings: List.of(bookings)),
            )),
            icon: const Icon(Icons.calendar_month),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: blush,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.content_cut, size: 38, color: burgundy),
                SizedBox(height: 10),
                Text('Your style. Your time.',
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold,
                    color: burgundy)),
                SizedBox(height: 5),
                Text('PROFESSIONAL HAIR & BEAUTY',
                  style: TextStyle(letterSpacing: 1.2, fontSize: 12)),
                SizedBox(height: 8),
                Text('Book your preferred barber in a few simple steps.'),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const _SectionTitle('1. Choose your barber'),
          ...barbers.map((b) => Card(
            child: RadioListTile<String>(
              value: b,
              groupValue: barber,
              activeColor: burgundy,
              title: Text(b, style: const TextStyle(fontWeight: FontWeight.w600)),
              secondary: const CircleAvatar(
                backgroundColor: blush,
                child: Icon(Icons.person, color: burgundy),
              ),
              onChanged: (v) => setState(() => barber = v),
            ),
          )),
          const SizedBox(height: 14),
          const _SectionTitle('2. Select a service'),
          DropdownButtonFormField<String>(
            value: service,
            decoration: const InputDecoration(border: OutlineInputBorder()),
            items: services.keys.map((s) =>
              DropdownMenuItem(value: s, child: Text('$s • ${services[s]} min'))
            ).toList(),
            onChanged: (v) { if (v != null) setState(() => service = v); },
          ),
          const SizedBox(height: 20),
          const _SectionTitle('3. Choose a date (2–7 days ahead)'),
          OutlinedButton.icon(
            onPressed: chooseDate,
            icon: const Icon(Icons.date_range),
            label: Text(dateLabel),
          ),
          const SizedBox(height: 16),
          const _SectionTitle('4. Choose a time'),
          Wrap(
            spacing: 8, runSpacing: 8,
            children: List.generate(10, (i) {
              final hour = 10 + i;
              final label = hour <= 12
                ? '${hour == 12 ? 12 : hour}:00 ${hour < 12 ? 'AM' : 'PM'}'
                : '${hour - 12}:00 PM';
              return ChoiceChip(
                label: Text(label),
                selected: time == label,
                onSelected: (_) => setState(() => time = label),
              );
            }),
          ),
          const SizedBox(height: 20),
          const _SectionTitle('5. Your details'),
          TextField(
            controller: nameController,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              labelText: 'Customer name', border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person_outline)),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Mobile number', border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.phone_android)),
          ),
          const SizedBox(height: 22),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: burgundy, padding: const EdgeInsets.all(16)),
            onPressed: submit,
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('Review & add demo booking'),
          ),
          const SizedBox(height: 12),
          const Text(
            'DEMO ONLY: bookings are not synced to a database, sent to the shop, '
            'or protected against double-booking. Connect a secure backend before real use.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: Text(text, style: const TextStyle(
      fontSize: 17, fontWeight: FontWeight.bold, color: burgundy)),
  );
}

class BookingList extends StatelessWidget {
  final List<Map<String, String>> bookings;
  const BookingList({super.key, required this.bookings});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Demo bookings')),
    body: bookings.isEmpty
      ? const Center(child: Text('No demo bookings yet.'))
      : ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: bookings.length,
          itemBuilder: (_, i) {
            final b = bookings[i];
            return Card(child: ListTile(
              leading: const Icon(Icons.event_available, color: burgundy),
              title: Text('${b['service']} • ${b['barber']}'),
              subtitle: Text('${b['name']} • ${b['phone']}\n${b['date']} at ${b['time']}'),
              isThreeLine: true,
            ));
          },
        ),
  );
}
